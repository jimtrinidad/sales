<script type="text/javascript">
$(document).ready(function(){
	$("#change").click(function(){
		if(!$("#change").hasClass('clicked')){
			var form_data = {
						old: $("#old").val(),
						newp: $("#new").val(),
						con: $("#con").val(),
						uID: $("#uID").val(),
						ajax: '1'
					};
			$.ajax({
				url: "<?php echo site_url('user/change'); ?>",
				type: 'POST',
				data: form_data,
				success: function(msg) {
						if(msg=='change'){
								alert('Password has been changed');
								location.reload(true);
						}
						else{
							alert(msg);
							$("#change").removeClass('clicked');
						}
					}
				});
			}//end of if clicked
		$("#change").addClass('clicked');
	});	//end save click
});
</script>
<div class="heading">CHANGE PASSWORD</div>
<input type="hidden" id="uID" value="<?php if(isset($uID)):echo $uID;endif; ?>">
<table width="99%" border="0" cellpadding="0" cellspacing="0">
	<tbody>
		<tr>
			<td align="right" width="120px">
				<p><label for="new">New Password:</label></p>
			</td>
			<td>
				<p><input type="password" style="width:100%;" name="new" id="new"></p>
			</td>
		</tr>
		<tr>
			<td align="right">
				<label for="con">Retype Password:</label>
			</td>
			<td>
				<input type="password" style="width:100%;" name="con" id="con">
			</td>
		</tr>				
		<tr>
			<td></td>
			<td align="left" class="buttons">
				<p><input type="button" style="width:100px" id="change" name="change" value="Save"></p>
			</td>
		</tr>
	</tbody>
</table>