<script type="text/javascript">
$(document).ready(function(){
	$(".delete").click(function(){
		var e = $(this).attr("id");
		confirm("Are you sure you want to disable this user?", function () {	
			$.ajax({
				url: '<?php echo site_url('user/delete');?>/' + e,
				type: 'GET',
				success : function(){
						location.reload(true);
					}
			});
		});
	});
	$(".enable").click(function(){
		var e = $(this).attr("id");
		confirm("Are you sure you want to enable this user?", function () {	
			$.ajax({
				url: '<?php echo site_url('user/enableuser');?>/' + e,
				type: 'GET',
				success : function(){
						location.reload(true);
					}
			});
		});
	});	
});
function userWall(id){
	var window_dimensions = "toolbars=no,menubar=no,location=no,scrollbars=no,resizable=yes,status=no";  
		window.open("<?php echo site_url('user/wall')."/"?>"+id,"_blank",  window_dimensions);     
	return true;
}
</script>
<div class="membercon">
	<div style="padding:10px;font-family: verdana;font-size:15px;font-weight:bold">List of Users</div>
	<div class="list">
		<a class="edit" rel="#overlay" href="<?php echo site_url('user/add')?>"><button>New User</button></a>
		<div>
			<table cellspacing="0" cellpadding="0" border="0">
			<thead>
				<tr>
				<th width="20px">#</th><th>Name</th><th>Date Added</th><th colspan="2">Last Login</th>
				</tr>
			</thead>
			<tbody id="tb">
			<?php $i=1+$counter;?>
			<?php foreach ($results->result_array() as $value):?>
				<tr <?php echo ($value['isActive']=='0')?"style='background:#bdbdbd'":" id='trover' "?>>
					<td style="font-size:11px;">
					<input type="hidden" value="<?php echo $value['id']?>"><?php echo $i;?> )</td>
					<td class="names">
						<?php if($value['isActive']=='1'):?>
							<a class="profile" id="<?php echo $value['id']?>" href="<?php echo site_url('user/profile')."/".$value['id']?>">
							<?php echo $value['lastname'].", ".$value['firstname'] ?></a>
						<?php else:?>
						<b><?php echo $value['lastname'].", ".$value['firstname'] ?></b>
						<?php endif;?></td>
					<td><?php echo date("F d, Y",strtotime($value['dateAdded']))?></td>
					<td><?php if($value['lastLoggin']!='0000-00-00 00:00:00'):echo date("F d, Y - g:i:s a",strtotime($value['lastLoggin']));else:echo "N/A";endif;?></td>
					<td align="center" class="opt">
						<?php if($value['isActive']=='1'):?>
						<a href="javascript:void()" id="<?php echo $value['id']?>" onClick="userWall(<?php echo $value['id']?>)">Wall</a> &nbsp; 
						<a id="<?php echo $value['id']?>" class="edit" rel="#overlay" href="<?php echo site_url('user/edit')?>/<?php echo $value['id']?>">Edit</a> &nbsp; 
						<a class="delete" id="<?php echo $value['id']?>">Disable</a>
						<?php else:?>
						<a class="enable" id="<?php echo $value['id']?>">Enable</a>
						<?php endif;?>
					</td>
				</tr>
				<?php $i++; ?>
			<?php endforeach;?>
			<tr>
			<td colspan="5">
			<?php echo $this->pagination->create_links()?>
			</td>
			</tr>
			</tbody>
			</table>
		</div>
	</div>
</div>