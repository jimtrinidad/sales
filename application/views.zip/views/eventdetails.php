<div id="editevent_panel">
	<form id="editEventForm">
	<div id="editpanel">
	<div class="header">
	<span style="float:left;margin:5px;font-weight:bold">Edit Event</span> 
	<div class="clearer"></div>
	</div>
		<div style="padding:10px;">
	<label for="eventType">Mode of Communication:</label>
			<select id="eventType">
				<option value="Incoming Call" <?php echo ($result['eventType']=="Incoming Call")?"selected='selected'":""?>>Incoming Call</option>
				<option value="Incoming Mail" <?php echo ($result['eventType']=="Incoming Mail")?"selected='selected'":""?>>Incoming Mail</option>
				<option value="Outgoing Call" <?php echo ($result['eventType']=="Outgoing Call")?"selected='selected'":""?>>Outgoing Call</option>
				<option value="Outgoing Mail" <?php echo ($result['eventType']=="Outgoing Mail")?"selected='selected'":""?>>Outgoing Mail</option>
			</select>
			<br>
		<label for="companyname">Company Name: </label><input style="width:376px" id="companyname" type="text" value="<?php echo $result['companyName']?>"><br>	
		Contact Person: <input type="text" style='width:155px' id='lastname' maxlength='50' value="<?php echo $result['lastname']?>">
				<input type="text" style="width:155px" id="firstname" maxlength="50" value="<?php echo $result['firstname']?>">
				<input type="text" style="width:45px" maxlength="2" id="mi" value="<?php echo $result['mi']?>"><br>
				<span style="margin-left:135px"><label for="lastname">Surname</label></span><span style="margin-left:115px"><label for="firstname">First Name</label></span>
				<span style="margin-left:60px"><label for="mi">MI</label></span>
				<br>
		<label for="position">Position: </label><input style="width:414px" id="position" type="text" value="<?php echo $result['position']?>"><br>
		Contacts: <input type="text" style="width:129px" id="telNo" maxlength="50" value="<?php echo $result['telephone']?>">
				<input type="text" style="width:129px" id="faxNo" maxlength="50" value="<?php echo $result['fax']?>">
				<input type="text" style="width:128px" id="mobileNo" maxlength="50" value="<?php echo $result['mobile']?>"><br>
				<span style="margin-left:95px"><label for="telNo">Telephone</label></span>
				<span style="margin-left:90px"><label for="faxNo">Fax</label></span>
				<span style="margin-left:100px"><label for="mobileNo">Mobile</label></span>
				<br>
				<label for="email">Email:</label><input style="width: 430px;" id="email" type="text" value="<?php echo $result['email']?>"><br>
				<label for="remark">Remark: </label>
				<select id="remark">
					<option></option>
					<option value="Opportunity" <?php echo ($result['remark']=="Opportunity")?"selected='selected'":""?>>Opportunity</option>
					<option value="Rejected" <?php echo ($result['remark']=="Rejected")?"selected='selected'":""?>>Rejected</option>
					<!-- <option value="noted">Noted</option> -->
				</select>
			<span class="otype <?php echo ($result['remark']=="Opportunity")?"":"hidden"?>">
				<label style="font-size:11px;" for="opptype">Opportunity Type: </label>
				<select id="opptype">
					<option value="Won" <?php echo ($result['opportunityType']=="Won")?"selected='selected'":""?>>Won</option>
					<option value="Loss" <?php echo ($result['opportunityType']=="Loss")?"selected='selected'":""?>>Loss</option>
					<option value="Pending" <?php echo ($result['opportunityType']=="Pending")?"selected='selected'":""?>>Pending</option>
				</select>
			</span>
			<span class="chance <?php echo ($result['opportunityType']=="Pending")?"":"hidden"?>">
				<label style="font-size:11px;" for="cpercent">Chance:</label>
				<input type="text" maxlength="3" style="width:35px" id="cpercent" value="<?php echo $result['cPercent']!=0?$result['cPercent']:""?>"><b>%</b>
			</span>
			<br>
			<table cellpadding="0" cellspacing="0" class="note <?php //echo ($result['opportunityType']=="Pending")?"":"hidden"?>">
				<tr>
					<td><label for="note">Note: </label></td><td><textarea style="width: 428px;height: 30px;" id="note"><?php echo $result['note']?></textarea></td>
				</tr>
			</table>
			<label for="refferal">Refferal:</label><input type="text" style="width:413px" id="refferal" value="<?php echo $result['refferal']?>">
			<div align="right">
				<button id="editsave" type="submit"><img src="assets/images/icons/save_edit.png">Save</button><button id="editcancel" type="button"><img src="assets/images/icons/cancel.png">Cancel</button>
			</div>										
		</div>
	</div>
<input type="hidden" id="detailsid" value="<?php echo $result['did']?>">	
<input type="hidden" id="infoid" value="<?php echo $result['infoid']?>">	
</form>
<script type="text/javascript">
$(document).ready(function(){
	$("#editevent_panel #remark").change(function(){
		if($("#editevent_panel #remark").val()=="Opportunity"){
			$("#editevent_panel .otype").removeClass('hidden');
			$("#editevent_panel #opptype").change();	
		}else{
			$("#editevent_panel .otype").addClass('hidden');
			$("#editevent_panel #opptype").change();
		}
	});
	
	$("#editevent_panel #opptype").change(function(){
		if($("#editevent_panel #opptype").val()=="Pending" && $("#editevent_panel #remark").val()=="Opportunity"){
			$("#editevent_panel .chance").removeClass('hidden');	
		}else{
			$("#editevent_panel .chance").addClass('hidden');
		}
	});
	

	$("#editEventForm").bind("submit",function(){		
		if(!$("#editEventForm").hasClass('clicked')){
			if($("#editevent_panel #remark").val()=="Opportunity"){
				var opptype = $("#editevent_panel #opptype").val();
			}else{
				var opptype = "";
			}
			var form_data = {
						eventType : $("#editevent_panel #eventType").val(),
						companyName : $("#editevent_panel #companyname").val(),
						lastname : $("#editevent_panel #lastname").val(),
						firstname : $("#editevent_panel #firstname").val(),
						mi : $("#editevent_panel #mi").val(),
						position : $("#editevent_panel #position").val(),
						telephone : $("#editevent_panel #telNo").val(),
						fax : $("#editevent_panel #faxNo").val(),
						mobile : $("#editevent_panel #mobileNo").val(),
						email : $("#editevent_panel #email").val(),
						remark : $("#editevent_panel #remark").val(),
						opportunityType : opptype,
						cPercent : $("#editevent_panel #cpercent").val(),
						note : $("#editevent_panel #note").val(),
						refferal : $("#editevent_panel #refferal").val(),
						dID : $("#editevent_panel #detailsid").val(),
						infoID : $("#editevent_panel #infoid").val(),
						ajax: '1'
					};
			$.ajax({
				url: "<?php echo site_url('main/editevent'); ?>",
				type: 'POST',
				data: form_data,
				success: function(msg) {
						if(msg=='edit'){
							var fdata = {
									id:$("#detailsid").val(),
									ajax:'1'
									};
							$.ajax({
								url : '<?php echo site_url('main/getDetails')?>',
								data : fdata,
								type : 'POST',
								success : function(emsg){
									refreshmaincontent("<?php echo my_session_value('userprogID') ?>","<?php echo my_session_value('dateID') ?>",<?php echo my_session_value('showalldays')?"'".my_session_value('showalldays')."'":"''"?>);
									$("#moredetailspanel").html(emsg);
								}
							});						
						}
						else if(msg.search("html")<0){
							alert(msg);
							$("#editEventForm").removeClass('clicked');
						}
						else{
							window.location.reload();
						}
				},
				error:function(){
					$("#editEventForm").removeClass('clicked');
				}
				});
		}//end if has class clicked
		$("#editEventForm").addClass('clicked');
		return false;
	});
			
});
</script>		
</div>

<div class="noborderlist">
<table>
	<tr>
		<td style="border-bottom:0;">
			<span>Mode of Communication:</span><b><?php echo $result['eventType']?></b><br>
			<span>Date / Time:</span><b><?php echo date("F j, Y / g:i:s A",strtotime($result['time']))?></b><br>
			<span>Remark:</span><b><?php echo $result['remark']?></b><br>
			<?php if($result['remark']=="Opportunity"):?><span>Status:</span><b><?php echo $result['opportunityType']?></b><?php endif;?>
			<?php if($result['opportunityType']=="Pending" && $result['cPercent']!=""):?><span>Chance:</span><b><?php echo $result['cPercent']?>%</b><br><?php elseif($result['remark']=="Opportunity"):echo "<br>"; endif;?>
			<?php if($result['note']!=""):?><span>Note:</span><b><?php echo $result['note']?></b><br><?php endif;?>			
			<span>Contact Person:</span><b><?php echo $result['lastname'].", ".$result['firstname'];echo $result['mi']!=""?" ".$result['mi'].".":"" ?></b><br>
			<span>Company Name:</span><b><?php echo $result['companyName']?></b><br>
			<span>Position:</span><b><?php echo $result['position']?></b><br>
			<span>Telephone:</span><b><?php echo $result['telephone']?></b><br>
			<span>Fax:</span><b><?php echo $result['fax']?></b><br>
			<span>Mobile:</span><b><?php echo $result['mobile']?></b><br>
			<span>Email:</span><b><?php echo $result['email']?></b><br>
			<span>Refferal:</span><b><?php echo $result['refferal']?></b><br>
		</td>
	</tr>
	<tr>
		<td class="" style="border-bottom:0;">
			<?php if(userPrivilege('canSendM')==1):?>
				<?php if(!empty($result['email'])):?>
				<button class="sendemail" id="<?php echo $result['did']?>"><img src="assets/images/icons/send_email_user.png">Send Email</button>
				<?php endif;?>
			<?php endif;?>
			<button id="history"><img src="assets/images/icons/history.png">History</button>
			<button id="editevent"><img src="assets/images/icons/edit.png">Edit</button>
			<button id="edelete"><img src="assets/images/icons/delete.png">Delete</button>
			<button id="ehide"><img src="assets/images/icons/cancel.png">Hide</button>
		</td>
	</tr>
</table>
</div>


<script type="text/javascript">
$(document).ready(function(){
	
	$('#editcancel').bind('click',function(e){
		$('#editevent_panel').toggle('fast');
		editevent=false;
	});
	$("#editevent_panel").hide();
	//$("#editevent_panel").draggable({handle: '.header'});
	var editevent = false;
	$('#editevent').click(function(e){	
		if(!editevent)
		{
			editevent=true;
			$("#editevent_panel").toggle('fast');
		}
		else
		{
			editevent=false;
			$("#editevent_panel").toggle(500);
		}		
	});	

	$("#ehide").click(function(){
		$("#moredetailspanel").animate({"right": "-520px"}, "fast");
		$("#history_panel").animate({"left": "-430px"}, "fast");
	});

	$("#edelete").click(function(){
		confirm("Are you sure you want to remove this record?", function () {	
			var fdata = {
					did : $("#detailsid").val(),
					infoid : $("#infoid").val(),
					ajax : '1'
					};
			$.ajax({
				url : '<?php echo site_url('main/deleteEvent')?>',
				data : fdata,
				type : 'POST',
				success : function(){
					refreshmaincontent("<?php echo my_session_value('userprogID') ?>","<?php echo my_session_value('dateID') ?>");
				}
			});
		});
	});

	$(".sendemail").bind("click",function(){
		var fdata = {
				detailsid : $(this).attr('id'),
				ajax : 1
				};
		$.ajax({
				url:'<?php echo site_url('main/emaileditor')?>',
				type: 'POST',
				data: fdata,
				success: function(msg){
						$("#emaileditor_panel").html(msg);
						$("#emaileditorholder").fadeIn('fast');
					}
			});
	});	

	var side_panel = false;
	$("#history").bind("click",function(){
		if(!side_panel){
			$("#history_panel").animate({"left": "0px"}, "fast");
			side_panel = true;
		}else{
			$("#history_panel").animate({"left": "-430px"}, "fast");
			side_panel = false;
		}
	});	

});
</script>