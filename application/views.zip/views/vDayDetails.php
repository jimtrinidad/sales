<script type="text/javascript">
$(document).ready(function(){
	
	$('#addevent_panel #close').bind('click',function(e){
		$('#addevent_panel').toggle(500);
		addevent=false;
	});
	$("#addevent_panel").hide();
	$("#addevent_panel").draggable({handle: '.header'});
	var addevent = false;
	$('#addevent').click(function(e){	
		if(!addevent)
		{
			addevent=true;
			$("#addevent_panel").toggle('fast');
		}
		else
		{
			addevent=false;
			$("#addevent_panel").toggle(500);
		}		
	});	
	$("#addevent_panel #remark").change(function(){
		if($("#addevent_panel #remark").val()=="Opportunity"){
			$("#addevent_panel .otype").removeClass('hidden');
			$("#addevent_panel #opptype").change();	
		}else{
			$("#addevent_panel .otype").addClass('hidden');
			$("#addevent_panel #opptype").change();
		}
	});
	

	$("#addevent_panel #opptype").change(function(){
		if($("#addevent_panel #opptype").val()=="Pending" && $("#addevent_panel #remark").val()=="Opportunity"){
			$("#addevent_panel .chance").removeClass('hidden');	
		}else{
			$("#addevent_panel .chance").addClass('hidden');
		}
	});	

			
});
</script>

<div id="historyholder">
	<div id="history_panel">
		
	</div>
</div>
<div id="eventdetailsholder" ><!-- CONTENT BOX FOR EVENT DETAILS  -->
	<div id="moredetailspanel">
	</div>
</div>

<div id="addevent_panel">
	<form id="addEventForm">
	<div class="header">
	<span style="float:left;margin:5px;font-weight:bold">New Event</span> 
	<span id="close" style="float: right;margin: 5px;font-weight: bold">x</span>
	<div class="clearer"></div>
	</div>
	<div style="padding:10px;">
	<span>Mode of Communication:</span>
		<select id="eventType">
			<option value="Incoming Call">Incoming Call</option>
			<option value="Incoming Mail">Incoming Mail</option>
			<option value="Outgoing Call">Outgoing Call</option>
			<option value="Outgoing Mail">Outgoing Mail</option>
		</select>
		<br>
	<label for="companyname">Company Name: </label><input style="width:386px" id="companyname" type="text"><br>	
	Contact Person: <input type="text" style='width:155px' id='lastname' maxlength='50' value="<?php echo isset($lastname)?$lastname:""?>">
			<input type="text" style="width:155px" id="firstname" maxlength="50" value="<?php echo isset($firstname)?$firstname:""?>">
			<input type="text" style="width:47px" maxlength="2" id="mi" value="<?php echo isset($mi)?$mi:""?>"><br>
			<span style="margin-left:135px"><label for="lastname">Surname</label></span><span style="margin-left:130px"><label for="firstname">First Name</label></span>
			<span style="margin-left:85px"><label for="mi">MI</label></span>
			<br>
	<label for="position">Position: </label><input style="width:424px" id="position" type="text" maxlength="50"><br>
	Contacts: <input type="text" style="width:130px" id="telNo" maxlength="50" value="<?php echo isset($workNo)?$workNo:""?>">
			<input type="text" style="width:129px" id="faxNo" maxlength="50" value="<?php echo isset($faxNo)?$faxNo:""?>">
			<input type="text" style="width:129px" id="mobileNo" maxlength="50" value="<?php echo isset($mobileNo)?$mobileNo:""?>"><br>
			<span style="margin-left:95px"><label for="telNo">Telephone</label></span>
			<span style="margin-left:110px"><label for="faxNo">Fax</label></span>
			<span style="margin-left:120px"><label for="mobileNo">Mobile</label></span>
			<br>
			<label for="email">Email:</label><input style="width: 440px;" id="email" type="text"><br>
			<label for="remark">Remark: </label>
			<select id="remark">
				<option></option>
				<option value="Opportunity">Opportunity</option>
				<option value="Rejected">Rejected</option>
				<!-- <option value="noted">Noted</option> -->
			</select>
		<span class="otype hidden">
			<label for="opptype">Opportunity Type: </label>
			<select id="opptype">
				<option value="Won">Won</option>
				<option value="Loss">Loss</option>
				<option value="Pending">Pending</option>
			</select>
		</span>
		<span class="chance hidden">
			<label for="cpercent">Chance:</label>
			<input type="text" maxlength="3" style="width:40px" id="cpercent"><b>%</b>
		</span>
		<br>
			<table cellpadding="0" cellspacing="0" class="note <?php //echo ($result['opportunityType']=="Pending")?"":"hidden"?>">
				<tr>
					<td><label for="note">Note: </label></td><td><textarea style="width: 442px;height: 30px;" id="note"></textarea></td>
				</tr>
			</table>
		<label for="refferal">Refferal:</label><input type="text" style="width:424px" id="refferal">
		<div align="right">
			<button type="submit" id="save"><img src="assets/images/icons/save_edit.png">Save</button>
		</div>										
	</div>
	</form>
<script type="text/javascript">
$(document).ready(function(){
	$("#addEventForm").bind("submit",function(){		
		if(!$("#addEventForm").hasClass('clicked')){
			if($("#addevent_panel #remark").val()=="Opportunity"){
				var opptype = $("#addevent_panel #opptype").val();
			}else{
				var opptype = "";
			}
			var form_data = {
						eventType : $("#addevent_panel #eventType").val(),
						companyName : $("#addevent_panel #companyname").val(),
						lastname : $("#addevent_panel #lastname").val(),
						firstname : $("#addevent_panel #firstname").val(),
						mi : $("#addevent_panel #mi").val(),
						position : $("#addevent_panel #position").val(),
						telephone : $("#addevent_panel #telNo").val(),
						fax : $("#addevent_panel #faxNo").val(),
						mobile : $("#addevent_panel #mobileNo").val(),
						email : $("#addevent_panel #email").val(),
						remark : $("#addevent_panel #remark").val(),
						opportunityType : opptype,
						cPercent : $("#addevent_panel #cpercent").val(),
						note : $("#addevent_panel #note").val(),
						refferal : $("#addevent_panel #refferal").val(),
						dateID : $("#dateid").val(),
						userprogid : $("#detailsupid").val(),
						ajax: '1'
					};
			$.ajax({
				url: "<?php echo site_url('main/addevent'); ?>",
				type: 'POST',
				data: form_data,
				success: function(msg) {
						if(msg=='add'){
								//alert('A new alumni has been added.');
								$('#addevent_panel').fadeOut('fast');
								refreshmaincontent("<?php echo my_session_value('userprogID') ?>","<?php echo my_session_value('dateID') ?>",<?php echo my_session_value('showalldays')?"'".my_session_value('showalldays')."'":"''"?>);							
						}
						else if(msg.search("html")<0){
							alert(msg);
							$("#addEventForm").removeClass('clicked');
						}
						else{
							window.location.reload();
						}
				},
				error:function(){
					//alert('haha');
				}
				});
		}//end if has class clicked
		$("#addEventForm").addClass('clicked');
		return false;//to stop reloading on submit
	});

	$("#listSearchForm").bind("submit",function(){
		var fdata = {
				searchkeyD : $("#searchkeyD").val(),
				searchvalD : $("#searchvalD").val(),
				etypeD : $("#etypeD").val(),
				remarkD : $("#remarkD").val(),
				statusD : $("#opptypeD").val(),
				upid : $("#detailsupid").val(),
				dateid : $("#detailsdateid").val(),
				showalldays : $("#showalldays").val(),
				ajax : '1'
				};
		$("#recordDetails").empty().html("<img style='margin:50px 0 50px 490px	;' src='<?php echo base_url() ?>assets/images/bigloader.gif'>");
		$.ajax({
			url : '<?php echo site_url('main/ajaxprogram')?>',
			type : 'POST',
			data : fdata,
			success : function(msg){
				$("#recordDetails").html(msg);
			},
			error : function(){
			}
		});
		return false;
	});		
			
});
</script>	
</div>
<div style="width: 100%;">
<input type="hidden" id="dateid" value="<?php echo $date->id?>">
<img src="<?php echo base_url()?>assets/photos/logo/<?php echo $program->logo?>" style="float:left;width: 60px;height: 50px;border: 0;padding:0px 5px;">
	<span>Program : </span><b><?php echo $program->title." ".$program->batch?></b><br>
	<?php if($showalldays==""):?><span>Date : </span><b><?php echo date("l, F j, Y",strtotime($date->date))?></b><br>
			<button id="addevent"><img src="assets/images/icons/contact_new.png">New Event</button>
	<?php else:?><span>Date : </span><b><?php echo date("F j, Y",strtotime($program->dateStart))?> - <?php echo date("F j, Y",strtotime($program->dateEnd))?></b><br>
	<?php endif;?>
</div>
<div class="clearer" style="margin-bottom: 2px;"></div>
<div class="list">
<form id="listSearchForm">
	<span>
		<select id="searchkeyD" style="width: 90px;">
			<option value="lastname">Lastname</option>
			<option value="firstname">Firstname</option>
			<option value="companyName">Company</option>
		</select>
		<input type="text" id="searchvalD" style="width: 130px;">
		<label for="etype">&nbsp;Mode of Comm: </label><select id="etypeD" style="max-width:140px;">
											<option value="">Any</option>
											<?php foreach ($events as $k=>$v):?>
											<option value="<?php echo $k?>"><?php echo $v?></option>
											<?php endforeach;?>	
										</select>													
		<label for="remark">Remark: </label><select id="remarkD">
											<option value="">Any</option>
											<option value="Opportunity">Opportunity</option>
											<option value="Rejected">Rejected</option>
										</select>
		<label for="opptype">Status: </label><select id="opptypeD">
											<option value="">Any</option>
											<option value="Won">Won</option>
											<option value="Loss">Loss</option>
											<option value="Pending">Pending</option>
										</select>					
		<button class="trigger" type="submit"><img src="assets/images/icons/find.png">Search</button>	
	</span>
</form>
	<div id="recordDetails">
		<table cellspacing="0" cellpadding="0" border="0">
			<thead>				
				<tr>
				<th width="30px">#</th><th><?php echo $showalldays==""?"Time":"Date/Time";?></th><th>Mode of Comm.</th><th>Contact Person</th><th>Company Name</th>
				<th>Telephone</th><th>Remark</th><th>Status</th><th></th>
				</tr>
			</thead>
			<tbody id="tb">
			<?php $i=1+$counter?>
			<?php foreach ($results as $value):?>
				<tr id="trover" rowid="<?php echo $value['did']?>" class="trdetails" <?php echo $value['latest']==0?"style='background:#dadadb'":""?>>
					<td style="font-size:11px;">
					<input type="hidden" value="<?php echo $value['did']?>"><?php echo $i;?> )</td>
					<td><?php echo $showalldays==""?date("g:i A",strtotime($value['time'])):date("M j/g:i A",strtotime($value['time'])) ?></td>
					<td><?php echo $value['eventType'] ?></td>					
					<td><?php echo $value['lastname'].", ".$value['firstname'];echo $value['mi']!=""?" ".$value['mi'].".":"" ?></td>
					<td><?php echo $value['companyName'] ?></td>
					<td><?php echo $value['telephone'] ?></td>
					<td><?php echo $value['remark'] ?></td>
					<td><?php echo $value['opportunityType'] ?></td>
						<td align="right">
							<?php if(userPrivilege('canSendM')==1):?>
								<?php if(!empty($value['email'])):?>
								<a class="sendemail" id="<?php echo $value['did']?>"><img src="assets/images/icons/send_email_user.png">Send Email</a> &nbsp;
								<?php endif;?>
							<?php endif;?>
						</td>					
				</tr>
				<?php $i++; ?>
			<?php endforeach;?>
			<?php echo "<tr><td align='right' colspan='9'><b>$msg</b></td></tr>";?>
			<tr>
				<td colspan="9">
					<div id="resultpages"><?php echo $this->ajaxpagination->create_links()?></div>
				</td>
			</tr>
			</tbody>
		</table>
	</div>
	<input type="hidden" id="userid" value="<?php echo my_session_value('uid')?>">
	<input type="hidden" value="<?php echo $program->programTempID?>" id="programTempID">
	<input type="hidden" id="detailsupid" value="<?php echo $upid?>">
	<input type="hidden" id="detailsdateid" value="<?php echo $dateid?>">
	<input type="hidden" id="showalldays" value="<?php echo $showalldays?>">
</div>
<script type="text/javascript">
function getDetails(id){
	var fdata = {
			id:id,
			ajax:'1'
			};
	$("#moredetailspanel").empty().html("<div class='infoloader'><img  src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
	$.ajax({
		url : '<?php echo site_url('main/getDetails')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#moredetailspanel").html(msg);
		},
		error : function(){
			//alert(id);
		}
	});
	$("#history_panel").empty();
	$.ajax({
		url : '<?php echo site_url('main/getHistory')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#history_panel").html(msg);
		},
		error : function(){
			//alert(id);
		}
	});	
}
$(document).ready(function(){
	$("#resultpages #pagination span").click(function(){
		$("#moredetailspanel").animate({"right": "-520px"}, "fast");
		$('#editevent_panel').hide();
		var fdata = {
				searchkeyD : $("#searchkeyD").val(),
				searchvalD : $("#searchvalD").val(),
				etypeD : $("#etypeD").val(),
				remarkD : $("#remarkD").val(),
				statusD : $("#opptypeD").val(),
				showalldays : $("#showalldays").val(),
					upid : $("#detailsupid").val(),
					dateid : $("#detailsdateid").val()
				};
		$.ajax({
			url : $(this).attr("href"),
			data : fdata,
			type : 'POST',
			success : function(res){
				$("#recordDetails").html(res);
			}
		});
	});	

	$(".trdetails").bind("click",function(){
		$('#editevent_panel #close').bind('click',function(e){
			$('#editevent_panel').fadeOut('fast');
			editevent=false;
		});
	});		
	
	var row = null;
	var moredetailspanel = false;
	$(".trdetails td:not(.opt)").bind("click",function(){
		var rowid = $(this).parent(".trdetails").attr('rowid');
		$('#editevent_panel').hide();
		if(row){
			if(moredetailspanel && rowid==row){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				$("#moredetailspanel").animate({"right": "-520px"}, "fast");
				moredetailspanel = false;
			}else if(moredetailspanel){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				$("#moredetailspanel").animate({"right": "-520px"}, "fast");
				$("#moredetailspanel").animate({"right": "0px"}, "fast");
				getDetails(rowid);
				moredetailspanel = true;
			}else{
				$("#copyevent_panel").fadeOut('fast');
				$("#right_panel").animate({"right": "-600px"}, "fast");
				$("#moredetailspanel").animate({"right": "0px"}, "fast");
				getDetails(rowid);
				moredetailspanel = true;				
			}
		}
		else
		{
			if(!moredetailspanel){
				$("#copyevent_panel").fadeOut('fast');
				$("#right_panel").animate({"right": "-600px"}, "fast");
				$("#moredetailspanel").animate({"right": "0px"}, "fast");
				getDetails(rowid);
				moredetailspanel = true;
			}
		}
		row = rowid;		
	});	

	$(".sendemail").bind("click",function(){
		var fdata = {
				detailsid : $(this).attr('id'),
				ajax : 1
				};
		$.ajax({
				url:'<?php echo site_url('main/emaileditor')?>',
				type: 'POST',
				data: fdata,
				success: function(msg){
						$("#emaileditor_panel").html(msg);
						$("#emaileditorholder").fadeIn('fast');
					}
			});
	});	

	var side_panel = false;
	$("#history").bind("click",function(){
		if(!side_panel){
			$("#history_panel").animate({"left": "0px"}, "fast");
			side_panel = true;
		}else{
			$("#history_panel").animate({"left": "-430px"}, "fast");
			side_panel = false;
		}
	});			
});
</script>