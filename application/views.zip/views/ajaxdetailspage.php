		<table cellspacing="0" cellpadding="0" border="0">
			<thead>				
				<tr>
				<th width="30px">#</th><th><?php echo $showalldays==""?"Time":"Date/Time";?></th><th>Mode of Comm.</th><th>Contact Person</th><th>Company Name</th>
				<th>Telephone</th><th>Remark</th><th>Status</th><th></th>
				</tr>
			</thead>
			<tbody id="tb">
			<?php $i=1+$counter?>
			<?php foreach ($results as $value):?>
				<tr id="trover" rowid="<?php echo $value['did']?>" class="trdetails" <?php echo $value['latest']==0?"style='background:#dadadb'":""?>>
					<td style="font-size:11px;">
					<input type="hidden" value="<?php echo $value['did']?>"><?php echo $i;?> )</td>
					<td><?php echo $showalldays==""?date("g:i A",strtotime($value['time'])):date("M j/g:i A",strtotime($value['time'])) ?></td>
					<td><?php echo $value['eventType'] ?></td>					
					<td><?php echo $value['lastname'].", ".$value['firstname'];echo $value['mi']!=""?" ".$value['mi'].".":"" ?></td>
					<td><?php echo $value['companyName'] ?></td>
					<td><?php echo $value['telephone'] ?></td>
					<td><?php echo $value['remark'] ?></td>
					<td><?php echo $value['opportunityType'] ?></td>
						<td align="right">
							<?php if(userPrivilege('canSendM')==1):?>
								<?php if(!empty($value['email'])):?>
								<a class="sendemail" id="<?php echo $value['did']?>">Send Email</a> &nbsp;
								<?php endif;?>
							<?php endif;?>
						</td>					
				</tr>
				<?php $i++; ?>
			<?php endforeach;?>
			<?php echo "<tr><td align='right' colspan='9'><b>$msg</b></td></tr>";?>
			<tr>
				<td colspan="9">
					<div id="resultpages"><?php echo $this->ajaxpagination->create_links()?></div>
				</td>
			</tr>
			</tbody>
		</table>
	<input type="hidden" id="detailsupid" value="<?php echo $upid?>">
	<input type="hidden" id="detailsdateid" value="<?php echo $dateid?>">
	<input type="hidden" id="showalldays" value="<?php echo $showalldays?>">
	
<script type="text/javascript">
function getDetails(id){
	var fdata = {
			id:id,
			ajax:'1'
			};
	$("#moredetailspanel").empty().html("<div class='infoloader'><img  src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
	$.ajax({
		url : '<?php echo site_url('main/getDetails')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#moredetailspanel").html(msg);
		},
		error : function(){
			//alert(id);
		}
	});
	$("#history_panel").empty();
	$.ajax({
		url : '<?php echo site_url('main/getHistory')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#history_panel").html(msg);
		},
		error : function(){
			//alert(id);
		}
	});	
}
$(document).ready(function(){
	$("#resultpages #pagination span").click(function(){
		$("#moredetailspanel").animate({"right": "-520px"}, "fast");
		$('#editevent_panel').hide();
		var fdata = {
				searchkeyD : $("#searchkeyD").val(),
				searchvalD : $("#searchvalD").val(),
				etypeD : $("#etypeD").val(),
				remarkD : $("#remarkD").val(),
				statusD : $("#opptypeD").val(),
				showalldays : $("#showalldays").val(),
					upid : $("#detailsupid").val(),
					dateid : $("#detailsdateid").val()
				};
		$.ajax({
			url : $(this).attr("href"),
			data : fdata,
			type : 'POST',
			success : function(res){
				$("#recordDetails").html(res);
			}
		});
	});	

	$(".trdetails").bind("click",function(){
		$('#editevent_panel #close').bind('click',function(e){
			$('#editevent_panel').fadeOut('fast');
			editevent=false;
		});
	});		
	
	var row = null;
	var moredetailspanel = false;
	$(".trdetails td:not(.opt)").bind("click",function(){
		var rowid = $(this).parent(".trdetails").attr('rowid');
		$('#editevent_panel').hide();
		if(row){
			if(moredetailspanel && rowid==row){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				$("#moredetailspanel").animate({"right": "-520px"}, "fast");
				moredetailspanel = false;
			}else if(moredetailspanel){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				$("#moredetailspanel").animate({"right": "-520px"}, "fast");
				$("#moredetailspanel").animate({"right": "0px"}, "fast");
				getDetails(rowid);
				moredetailspanel = true;
			}else{
				$("#copyevent_panel").fadeOut('fast');
				$("#right_panel").animate({"right": "-500px"}, "fast");
				$("#moredetailspanel").animate({"right": "0px"}, "fast");
				getDetails(rowid);
				moredetailspanel = true;				
			}
		}
		else
		{
			if(!moredetailspanel){
				$("#copyevent_panel").fadeOut('fast');
				$("#right_panel").animate({"right": "-500px"}, "fast");
				$("#moredetailspanel").animate({"right": "0px"}, "fast");
				getDetails(rowid);
				moredetailspanel = true;
			}
		}
		row = rowid;		
	});	

	$(".sendemail").bind("click",function(){
		var fdata = {
				detailsid : $(this).attr('id'),
				ajax : 1
				};
		$.ajax({
				url:'<?php echo site_url('main/emaileditor')?>',
				type: 'POST',
				data: fdata,
				success: function(msg){
						$("#emaileditor_panel").html(msg);
						$("#emaileditorholder").fadeIn('fast');
					}
			});
	});	

	var side_panel = false;
	$("#history").bind("click",function(){
		if(!side_panel){
			$("#history_panel").animate({"left": "0px"}, "fast");
			side_panel = true;
		}else{
			$("#history_panel").animate({"left": "-430px"}, "fast");
			side_panel = false;
		}
	});			
});
</script>