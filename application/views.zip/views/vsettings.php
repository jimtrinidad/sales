<div class="membercon">
	<div class="list">
	<div class="header">General Settings</div>
		<div><span><b>Allowed IP Address</b> (separated by comma)</span><br>
			<textarea id="allowedip" style="width: 410px"><?php echo implode(', ', $allowedip)?></textarea>
		</div>
		<div style="clear:both;position:relative;top:5px;" align="left"><input type="button" value="Save" name="saveset" id="saveset"><span id="mesg"></span>	</div>	
	</div>
</div>
<script type="text/javascript">
$("#saveset").bind('click',function(){
	var set_data = {
			allowedip : $("#allowedip").val(),						
			ajax : 1
		};
	$.ajax({
		url: "<?php echo site_url('settings/saveset'); ?>",
		type: 'POST',
		data: set_data,
		success: function() {
			$("#mesg").html("Saved...").fadeIn('slow');
			$("#mesg").fadeOut('slow');
		},
		error: function(){
			$("#mesg").html("Error on Saving...").fadeIn('slow');
			$("#mesg").fadeOut('slow');
		}
	});//ajax end
});
</script>	