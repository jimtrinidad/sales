<script type="text/javascript">
$(document).ready(function(){
	$("#emaileditor_panel").draggable({
		handle:'#emaileditorheader',
		scroll: false
	});
	
	$( "#emaileditorheader #close" ).click(function(){
		$( "#emaileditorholder" ).fadeOut('fast');
	});

	$("#contacts_panel").draggable({
		handle:'#contactsheader',
		scroll: false
	});
	
	$( "#contactsheader #close" ).click(function(){
		$("#contactstrigger").removeClass('clicked');
		$("#contactsholder" ).fadeOut('fast');
	});	

	<?php if(!isset($result)):?>	
	$("#contactstrigger").bind("click",function(){
		$("#contactlist .addTrigger").die();
		$("#contactEmailTo .addTrigger").die();
		if(!$("#contactstrigger").hasClass('clicked')){
			<?php if($fromDashboard==1):?>
			var fdata = {
					day : $("#day").val(),
					program : $("#program").val(),
					status : $("#status").val(),
					lw : $("#lw").val(),
					ajax:1
					};
			<?php else:?>
			var fdata = {
					ajax:1
					};
			<?php endif;?>	
			$.ajax({
				url:'<?php echo ($fromDashboard==1)?site_url('dashboard/showcontacts'):site_url('main/showcontacts');?>',
				type:'POST',
				data:fdata,
				success:function(msg){
					$("#contactscontainer").html(msg);
					$("#contactsholder").fadeIn('fast');
				},
				error:function(){
					alert('eerr');
					$("#contactstrigger").removeClass('clicked');
				}
			});
		}
		$("#contactstrigger").addClass('clicked');		
	});	
	<?php endif;?>
		
});
</script>
<div id="contactsholder" class="hidden">
	<div id="contacts_panel">
		<div id="contactsheader">
			<span style="float:left;margin:5px;padding: 0;">Contacts</span> 
			<span id="close" style="float: right;margin: 5px;">x</span>
			<div class="clearer"></div>		
		</div>
		<div id="contactscontainer"></div>
	</div>
</div>

<input type="hidden" id="detailsid" value="<?php echo isset($result)?$result['did']:""?>">
		<div id="emaileditorheader">
			<span style="float:left;margin:5px;padding: 3px;">Email Editor</span> 
			<span id="close" style="float: right;margin: 5px;padding: 2px;">x</span>
			<div class="clearer"></div>
		</div>
		<div id="emaileditorcontainer">
			
			<table width="100%" border="0" cellpadding="2" cellspacing="0">
				<tbody>
					<tr  style="padding:5px;" >
						<td class="emaillabel" align="right"><div style="padding-left: 40px;cursor: pointer;" id="contactstrigger"><label style="cursor: pointer;" for="to">To:</label></div></td>
						<td style="padding-bottom:1px;">
							<?php if(isset($result)):?><span style="font-size: 12px;font-weight: bold;color: #333;margin-left:2px;"><?php echo $result['firstname']." ".$result['lastname'];?></span>
							<?php else:?><textarea id="emailbox" style="width:705px;height: 20px;"></textarea>
							<?php endif;?>
						</td>
						<td><span id="loader"><span class="sendbotton" id="send">Send</span></span></td>
					</tr>
					<tr>
						<td class="emaillabel"  align="right"><div style="padding-left: 12px;"><label for="subject"">Subject:</label></div></td>
						<td style="padding-bottom:1px;" colspan="2"><input name="subject" value="" id="subject" type="text" style="width:775px;font-weight:bold;margin-left:2px;margin-top:1px;"/></td>
					</tr>
					<tr>
						<td colspan="3">
						<textarea name="emessage" id="message"></textarea>
						<script type="text/javascript">
							if(CKEDITOR.instances['message']){
							   delete CKEDITOR.instances['message'];
							}
							CKEDITOR.replace( 'message',{
								toolbar: [
									['Source','-','Preview'],
								    ['Cut','Copy','Paste','PasteText','PasteFromWord','-','Print', 'SpellChecker', 'Scayt'],
								    ['Undo','Redo','-','SelectAll'],
								    ['Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField'],
								    ['Bold','Italic','Underline','Strike','-','Subscript','Superscript'],
								    ['NumberedList','BulletedList','-','Outdent','Indent','Blockquote','CreateDiv'],
								    ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
								    ['BidiLtr', 'BidiRtl'],
								    ['Link','Unlink','Anchor'],
								    ['Image','Table','HorizontalRule','Smiley','SpecialChar','PageBreak'],
								    ['Styles','Format','Font','FontSize'],
								    ['TextColor','BGColor'],
								    ['Maximize']
							    ],
						        uiColor : '#dbdbdb',
						        height: 300,
						        resize_enabled  : true,
						        resize_maxWidth: 848,
						        resize_minWidth: 848,
						        skin : 'kama',
						        disableNativeSpellChecker : false
						    });						
						</script>
						<script type="text/javascript">
							function sendClick(){
								var strarray = new Array();
								<?php if(!isset($result)):?>
									var str = $("#emailbox").val();
									strarray = str.split(',');
								<?php endif;?>
								if(strarray.length <= 10){
									sendemail();
								}else{
									alert('Only 10 emails is allowed per send. You have ' + strarray.length);
								}
							}
							function sendemail(){
								if(!$("#send").hasClass('clicked')){				
									var form_data = {
												subject:$("#subject").val(),
												message: CKEDITOR.instances.message.getData(),
												detailsid:$("#detailsid").val(),
												emailbox: $("#emailbox").val(),
												ajax: '1'
											};
									$("#loader").empty().html('<img style="width:23px;height:18px;" src="<?php echo base_url()?>assets/images/searchloader.gif" />');
									$.ajax({
										url: "<?php echo site_url('main/sendemail'); ?>",
										type: 'POST',
										data: form_data,
										success: function(msg) {
												if(msg=="invalidemail"){
													alert("Please make sure that all addresses are properly formed.");
													$("#loader").empty().html('<span class="sendbotton" id="send" onClick="sendClick()">Send</span>');
													$("#send").removeClass('clicked');
												}else{
													alert(msg);
													$( "#emaileditorholder" ).fadeOut('fast');
												}
											}
										});
								}//end of if clicked
								$("#send").addClass('clicked');
							}
							
							$(document).ready(function(){
								$("#send").bind("click",function(){
									sendClick();
								});
							});
						</script>
						</td>
					</tr>
				</tbody>
			</table>		
		</div>