<script type="text/javascript">
$(document).ready(function(){
	
	$('#copyevent_panel #close').bind('click',function(e){
		$('#copyevent_panel').fadeOut('fast');
		copyinfo=false;
	});
	$("#copyevent_panel").draggable({handle: '.header'});
	
	$("#copyevent_panel #remark").change(function(){
		if($("#copyevent_panel #remark").val()=="Opportunity"){
			$("#copyevent_panel .otype").removeClass('hidden');
			$("#copyevent_panel #opptype").change();	
		}else{
			$("#copyevent_panel .otype").addClass('hidden');
			$("#copyevent_panel #opptype").change();
		}
	});
	
	$("#copyevent_panel #opptype").change(function(){
		if($("#copyevent_panel #opptype").val()=="Pending" && $("#copyevent_panel #remark").val()=="Opportunity"){
			$("#copyevent_panel .chance").removeClass('hidden');	
		}else{
			$("#copyevent_panel .chance").addClass('hidden');
		}
	});
		
			
});
</script>
<div>
	<form id="copyEventForm">
	<div class="header">
	<span style="float:left;margin:5px;font-weight:bold">New Event From Old Record</span> 
	<span id="close" style="float: right;margin: 5px;font-weight: bold">x</span>
	<div class="clearer"></div>
	</div>
	<div style="padding:10px;">
	<span>Mode of Communication:</span>
		<select id="eventType">
			<option></option>
			<option value="Incoming Call">Incoming Call</option>
			<option value="Incoming Mail">Incoming Mail</option>
			<option value="Outgoing Call">Outgoing Call</option>
			<option value="Outgoing Mail">Outgoing Mail</option>
		</select>
		<br>
	<label for="companyname">Company Name: </label><input style="width:386px" id="companyname" type="text" value="<?php echo isset($record)?$record->companyName:""?>"><br>	
	Contact Person: <input type="text" style='width:155px' id='lastname' maxlength='50' value="<?php echo isset($record)?$record->lastname:""?>">
			<input type="text" style="width:155px" id="firstname" maxlength="50" value="<?php echo isset($record)?$record->firstname:""?>">
			<input type="text" style="width:47px" maxlength="2" id="mi" value="<?php echo isset($record)?$record->mi:""?>"><br>
			<span style="margin-left:135px"><label for="lastname">Surname</label></span><span style="margin-left:130px"><label for="firstname">First Name</label></span>
			<span style="margin-left:85px"><label for="mi">MI</label></span>
			<br>
	<label for="position">Position: </label><input style="width:424px" id="position" type="text"><br>
	Contacts: <input type="text" style="width:130px" id="telNo" maxlength="50" value="<?php echo isset($record)?$record->telephone:""?>">
			<input type="text" style="width:129px" id="faxNo" maxlength="50" value="<?php echo isset($record)?$record->fax:""?>">
			<input type="text" style="width:129px" id="mobileNo" maxlength="50" value="<?php echo isset($record)?$record->mobile:""?>"><br>
			<span style="margin-left:95px"><label for="telNo">Telephone</label></span>
			<span style="margin-left:110px"><label for="faxNo">Fax</label></span>
			<span style="margin-left:120px"><label for="mobileNo">Mobile</label></span>
			<br>
			<label for="email">Email:</label><input style="width: 440px;" id="email" type="text" value="<?php echo isset($record)?$record->email:""?>"><br>
			<label for="remark">Remark: </label>
			<select id="remark">
				<option></option>
				<option value="Opportunity">Opportunity</option>
				<option value="Rejected">Rejected</option>
				<!-- <option value="noted">Noted</option> -->
			</select>
		<span class="otype hidden">
			<label for="opptype">Opportunity Type: </label>
			<select id="opptype">
				<option value="Won">Won</option>
				<option value="Loss">Loss</option>
				<option value="Pending">Pending</option>
			</select>
		</span>
		<span class="chance hidden">
			<label for="cpercent">Chance:</label>
			<input type="text" maxlength="3" style="width:40px" id="cpercent"><b>%</b>
		</span>
		<br>
			<table cellpadding="0" cellspacing="0" class="note <?php //echo ($result['opportunityType']=="Pending")?"":"hidden"?>">
				<tr>
					<td><label for="note">Note: </label></td><td><textarea style="width: 442px;height: 30px;" id="note"></textarea></td>
				</tr>
			</table>
		<label for="refferal">Refferal:</label><input type="text" style="width:424px" id="refferal">
		<div align="right">
			<button type="submit" id="csave">Save</button>
		</div>										
	</div>
	<input type="hidden" id="infoid" value="<?php echo isset($record)?$record->id:""?>">
	<input type="hidden" id="userprogid" value="<?php echo isset($record)?$record->userprogid:""?>">
	<input type="hidden" id="newuserprogid" value="<?php echo my_session_value('userprogID')?my_session_value('userprogID'):""?>">	
	</form>
<script type="text/javascript">
$(document).ready(function(){
	$("#copyEventForm").bind("submit",function(){		
		if(!$("#copyEventForm").hasClass('clicked')){
			if($("#copyevent_panel #remark").val()=="Opportunity"){
				var opptype = $("#copyevent_panel #opptype").val();
			}else{
				var opptype = "";
			}
			var form_data = {
						eventType : $("#copyevent_panel #eventType").val(),
						companyName : $("#copyevent_panel #companyname").val(),
						lastname : $("#copyevent_panel #lastname").val(),
						firstname : $("#copyevent_panel #firstname").val(),
						mi : $("#copyevent_panel #mi").val(),
						position : $("#copyevent_panel #position").val(),
						telephone : $("#copyevent_panel #telNo").val(),
						fax : $("#copyevent_panel #faxNo").val(),
						mobile : $("#copyevent_panel #mobileNo").val(),
						email : $("#copyevent_panel #email").val(),
						remark : $("#copyevent_panel #remark").val(),
						opportunityType : opptype,
						cPercent : $("#copyevent_panel #cpercent").val(),
						refferal : $("#copyevent_panel #refferal").val(),
						note : $("#copyevent_panel #note").val(),
						dateID : $("#dateid").val(),
						infoID : $("#copyevent_panel #infoid").val(),
						
						userprogid : $("#userprogid").val(),
						newuserprogid : $("#newuserprogid").val(),
						
						ajax: '1'
					};
			$.ajax({
				url: "<?php echo site_url('main/copyinfo'); ?>",
				type: 'POST',
				data: form_data,
				success: function(msg) {
						if(msg=='add'){
								//alert('A new alumni has been added.');
								$('#copyevent_panel').fadeOut('fast');
								refreshmaincontent("<?php echo my_session_value('userprogID') ?>","<?php echo my_session_value('dateID') ?>");							
						}
						else if(msg.search("html")<0){
							alert(msg);
							$("#copyEventForm").removeClass('clicked');
						}
						else{
							window.location.reload();
						}
				},
				error:function(){
					//alert('haha');
				}
				});
		}//end if has class clicked
		$("#copyEventForm").addClass('clicked');
		return false;
	});
			
});
</script>	
</div>