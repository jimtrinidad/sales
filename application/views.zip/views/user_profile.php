<script type="text/javascript">
$(document).ready(function(){
	$(".editmini[rel]").overlay({

		mask	: '#cdcdcd',
		effect	: 'default',
		left	: 'center',
		top		: '5%',
		speed   : 0,
		fixed	: false,
		closeOnClick:false,
		onBeforeLoad: function() {			

			var loc = this.getTrigger().attr("href");
			var fdata = {
					refid : this.getTrigger().attr("id"),
					ajax: '1'
					};
			$.ajax({
				url: loc,
				data: fdata,
				type: 'POST',
				success : function(content){
						$(".contentWrapMini").html(content);
					}
			});
			
		},
		onClose: function(){
				//location.reload(true);
			}
	});	
	
	$(".delete").click(function(){
		var e = $(this).attr("id");
		var msg = $(this).attr("msg");
		var header = $(this).attr("header");
		var loc = $(this).attr("loc");
		confirm(msg, function () {	
			$.ajax({
				url: loc + '/' + e,
				type: 'GET',
				success : function(msg){
					//alert(msg)
						location.reload(true);
					}
			});
		},header);
	});
});
function openwall(){
	var window_dimensions = "toolbars=no,menubar=no,location=no,scrollbars=no,resizable=yes,status=no";  
		window.open("<?php echo site_url('user/wall')."/".$id?>","_blank",  window_dimensions);     
	return true;
}
</script>
<div class="membercon">
	<div class="header"><?php echo $lastname.", ".$firstname?><span style="float:right;"><a style="color:#ffffff" href="<?php echo site_url('user/manage')?>">Back</a></span></div>
	<div>
		<span>Last login:<b> <?php if($lastloggin!='0000-00-00 00:00:00'):echo date("l, F j, Y - g:i:s a",strtotime($lastloggin));else:echo "N/A";endif;?></b></span><br>
		<span>Date added:<b> <?php echo date("F d, Y",strtotime($dateadded))?></b></span><br>
		<span>Email:<b> <?php echo $email?></b></span><br>
		<span><a href="javascript:void()" id="<?php echo $id?>" onClick="openwall()">Wall</a></span><br>
		<span><a class="delete" header="Reset Login Attempts" loc="<?php echo site_url('user/resetLogin')?>" id="<?php echo $id?>">Reset Login Attempts</a></span><br>
		<span><a class="edit" href="<?php echo site_url('user/password')?>/<?php echo$id?>" rel="#overlay" id="<?php echo $id?>">Change Password</a></span><br>
		<span><a id="<?php echo $id?>" class="edit" rel="#overlay" href="<?php echo site_url('user/edit')?>/<?php echo $id?>">Edit</a></span><br><br>
	</div>
	<div class="header">Activities</div>
	<div class="list">
		<div>
			<table cellspacing="0" cellpadding="0" border="0">
			<thead>
				<tr>
				<th width="30px">#</th><th>Actions</th><th>IP Addess</th><th>Date Time</th>
				<th><span style="float:right;"><a msg="Are you sure you want to remove all the logs?" loc="<?php echo site_url('user/deletealltrails')?>" class="delete" style="color:#fff" id="<?php echo $id?>">Delete All</a></span></th>
				</tr>
			</thead>
			<tbody id="tb">
			<?php $i=1+$counter;?>
			<?php foreach ($results->result_array() as $value):?>
				<tr id="trover">
					<td style="font-size:11px;">
					<?php echo $i;?> )</td>
					<td><?php echo $value['action']?></td>
					<td><?php echo $value['ipaddress']?></td>
					<td width="200px"><?php echo date("F j, Y - g:i:s a",strtotime($value['datetime']))?></td>
					<td align="center" class="opt">
						<a class="delete"  msg="Are you sure you want to remove this log?" loc="<?php echo site_url('user/deletetrail')?>" id="<?php echo $value['id']?>">Delete</a>
					</td>
				</tr>
				<?php $i++; ?>
				<?php endforeach;?>
				<?php echo "<tr><td align='right' colspan='5'><b>$msg</b></td></tr>";?>			
				<tr>
					<td colspan="5">
					<?php echo $this->pagination->create_links()?>
					</td>
				</tr>
			</tbody>
			</table>
		</div>
	</div>
</div>