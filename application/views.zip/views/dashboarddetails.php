<script type="text/javascript">
$(document).ready(function(){
	$( "#dashboarddetailsheader #close" ).click(function(){
		$( "#dashboarddetailsholder" ).fadeOut('fast');
	});

	$("#dashboarddetails_panel").draggable({
		handle:'#dashboarddetailsheader',
		scroll: false
	});
	$("#dashboarddetails_panel").resizable({alsoResize: '#dashboarddetailscontainer'});

	$(".sendemail").bind("click",function(){
		var fdata = {
				detailsid : $(this).attr('id'),
				ajax : 1
				};
		$.ajax({
				url:'<?php echo site_url('main/emaileditor')?>',
				type: 'POST',
				data: fdata,
				success: function(msg){
						$("#emaileditor_panel").html(msg);
						$("#emaileditorholder").fadeIn('fast');
					}
			});
	});	

	$(".semail").bind("click",function(){
		var fdata = {
				dashboard:1,
				ajax : 1
				};
		$.ajax({
				url:'<?php echo site_url('main/emaileditor')?>',
				type: 'POST',
				data: fdata,
				success: function(msg){
						$("#emaileditor_panel").html(msg);
						$("#emaileditorholder").fadeIn('fast');
					}
			});
	});		

	$("#sortTable").tablesorter({
		cssHeader : 'thHeader'
	}); 
	
});
</script>
		<div id="dashboarddetailsheader">
			<span style="float:left;margin:5px;padding: 3px;">Details</span> 
			<span id="close" style="float: right;margin: 5px;padding: 2px;">x</span>
			<div class="clearer"></div>
		</div>
		<div id="dashboarddetailscontainer">
<div class="noborderlist">
<?php if(userPrivilege('canSendM')==1):?>
		<a style="padding:3px;float:right;margin-right:5px;" class="semail"><b>Email All</b></a>
<?php endif;?>		
		<table cellspacing="0" cellpadding="0" border="0" id="sortTable">
			<thead>				
				<tr>
				<th width="20px">#</th><th>Date/Time</th><th>Mode of Comm.</th><th>Status</th><th>Contact Person</th><th>Company Name</th>
				<th>Telephone</th><th>Mobile</th><th>Fax</th><th>Added by</th><th></th>
				</tr>
			</thead>
			<tbody id="tb">
			<?php $i=1?>
			<?php foreach ($records as $value):?>
				<tr id="trover" rowid="<?php echo $value['did']?>" class="trdetails" >
					<td style="font-size:11px;">
					<input type="hidden" value="<?php echo $value['did']?>"><?php echo $i;?> )</td>
					<td><?php echo date("j M, y / g:i a",strtotime($value['time'])) ?></td>
					<td><?php echo $value['eventType'] ?></td>
					<td><?php echo $value['status'] ?></td>						
					<td><?php echo $value['lastname'].", ".$value['firstname'];echo $value['mi']!=""?" ".$value['mi'].".":"" ?></td>
					<td><?php echo $value['companyName'] ?></td>
					<td><?php echo $value['telephone'] ?></td>
					<td><?php echo $value['mobile'] ?></td>	
					<td><?php echo $value['fax'] ?></td>
					<td><?php echo $value['user'] ?></td>	
						<td align="right">
							<?php if(userPrivilege('canSendM')==1):?>
								<?php if(!empty($value['email'])):?>
								<a class="sendemail" id="<?php echo $value['did']?>">Send Email</a> &nbsp;
								<?php endif;?>
							<?php endif;?>
						</td>		
				</tr>
				<?php $i++; ?>
			<?php endforeach;?>
			</tbody>
		</table>
</div>
<input type="hidden" value="<?php echo $filters['lw']?>" id="lw">
<input type="hidden" value="<?php echo $date?>" id="day">
<input type="hidden" value="<?php echo $filters['program']?>" id="program">
<input type="hidden" value="<?php echo $filters['status']?>" id="status">			
		</div>