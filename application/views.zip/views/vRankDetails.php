<script type="text/javascript">
$(document).ready(function(){
	$( "#rankdetailsheader #close" ).click(function(){
		$( "#rankdetailsholder" ).fadeOut('fast');
	});

	$("#rankdetails_panel").draggable({
		handle:'#rankdetailsheader',
		scroll: false
	});
	$("#rankdetails_panel").resizable({alsoResize: '#rankdetailscontainer'});
	
	
});
</script>
		<div id="rankdetailsheader">
			<span style="float:left;margin:5px;padding: 3px;">Details</span> 
			<span id="close" style="float: right;margin: 5px;padding: 2px;">x</span>
			<div class="clearer"></div>
		</div>
		<div id="rankdetailscontainer">
			<div class="noborderlist">	
					<table cellspacing="0" cellpadding="0" border="0">
						<thead>				
							<tr>
							<th width="20px">#</th><th>Date/Time</th><th>Program</th><th>Mode of Comm.</th><th>Status</th><th>Contact Person</th><th>Company Name</th>
							<th>Telephone</th><th>Mobile</th><th>Fax</th>
							</tr>
						</thead>
						<tbody id="tb">
						<?php $i=1?>
						<?php foreach ($records as $value):?>
							<tr id="trover" rowid="<?php echo $value['did']?>" class="trdetails" >
								<td style="font-size:11px;">
								<input type="hidden" value="<?php echo $value['did']?>"><?php echo $i;?> )</td>
								<td><?php echo date("F j, Y / g:i:s a",strtotime($value['time'])) ?></td>
								<td><?php echo $value['program'] ?></td>
								<td><?php echo $value['eventType'] ?></td>
								<td><?php echo $value['status'] ?></td>						
								<td><?php echo $value['lastname'].", ".$value['firstname'];echo $value['mi']!=""?" ".$value['mi'].".":"" ?></td>
								<td><?php echo $value['companyName'] ?></td>
								<td><?php echo $value['telephone'] ?></td>
								<td><?php echo $value['mobile'] ?></td>	
								<td><?php echo $value['fax'] ?></td>		
							</tr>
							<?php $i++; ?>
						<?php endforeach;?>
						</tbody>
					</table>
			</div>		
		</div>