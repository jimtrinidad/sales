<script type="text/javascript">
function getRecord(id){
	var fdata = {
			id:id,
			ajax:'1'
			};
	$("#copyevent_panel").empty().html("<div class='infoloader'><img style='margin-left:20px;' src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
	$.ajax({
		url : '<?php echo site_url('main/getOldRecForEditor')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#copyevent_panel").html(msg);
		},
		error : function(){
			//alert('g');
		}
	});
}
function getHistory(id){
	var fdata = {
			id:id,
			showall : 1,
			ajax:'1'
			};
	$("#history_panel").empty();
	$.ajax({
		url : '<?php echo site_url('main/getHistory')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#history_panel").html(msg);
		},
		error : function(){
			//alert(id);
		}
	});	
}
$(document).ready(function(){

	$("#copyevent_panel").hide();
	$("#copyevent_panel").draggable({handle: '.header'});
	
	var copyinfo = false;
	var row = null;
	$(".copyinfo").bind("click",function(){
		if(row){
			if(copyinfo && $(this).attr('id')==row){
				$("#copyevent_panel").fadeOut('fast');
				copyinfo = false;
			}else if(copyinfo){
				$("#copyevent_panel").fadeOut('fast');
				getRecord($(this).attr('id'));
				$("#copyevent_panel").fadeIn('fast');
				copyinfo = true;
			}else{
				$("#copyevent_panel").fadeIn('fast');
				getRecord($(this).attr('id'));
				copyinfo = true;				
			}
		}
		else
		{
			if(!copyinfo){
				$("#copyevent_panel").fadeIn('fast');
				getRecord($(this).attr('id'));
				copyinfo = true;
			}
		}
		row = $(this).attr('id');		
	});

	
	var history = false;
	var hisRow = null;
	$(".history").bind("click",function(){
		if(hisRow){
			if(history && $(this).attr('id')==hisRow){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				history = false;
			}else if(history){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				getHistory($(this).attr('id'));
				$("#history_panel").animate({"left": "0px"}, "fast");
				history = true;
			}else{
				$("#history_panel").animate({"left": "0px"}, "fast");
				getHistory($(this).attr('id'));
				history = true;				
			}
		}
		else
		{
			if(!history){
				$("#history_panel").animate({"left": "0px"}, "fast");
				getHistory($(this).attr('id'));
				history = true;
			}
		}
		hisRow = $(this).attr('id');		
	});						
	
			
});
</script>

<div id="copyevent_panel">

</div>


<script type="text/javascript">
$(document).ready(function(){

	$("#archiveFilterForm").bind("submit",function(){
		var sdata = {
				searchkey : $("#searchkey").val(),
				searchval : $("#searchval").val(),
				searchprog : $("#searchprog").val(),
				searchstatus : $("#searchstatus").val(),
				userid : $("#userid").val(),
				programtempid : $("#programtempid").val(),
				ajax : 1
			};
		$("#tbinfos").empty().html("<div class='infoloader' style='width:560px;'><img style='left:245px;' src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
		$.ajax({
			url : "<?php echo site_url('main/ajaxoldrecords')?>",
			data : sdata,
			type : 'POST',
			success : function(sres){
				$("#tbinfos").html(sres);
			}
		});	
		return false;	
	});	
		
	$("#infopages #pagination span").click(function(){
		$("#tbinfos").empty().html("<div class='infoloader' style='width:560px;'><img style='left:245px;' src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
		$.ajax({
			url : $(this).attr("href"),
			type : 'GET',
			success : function(res){
				$("#tbinfos").html(res);
			}
			,error:function(){alert('a');}
		});
	});		

});
</script>	
<form id="archiveFilterForm">
	<div style="padding:4px 4px 0 6px;">
		<select id="searchkey" style="width: 90px;">
			<option value="lastname" <?php echo $filter['searchkey']=="lastname"?"selected='selected'":""?>>Lastname</option>
			<option value="firstname" <?php echo $filter['searchkey']=="firstname"?"selected='selected'":""?>>Firstname</option>
			<option value="companyName" <?php echo $filter['searchkey']=="companyName"?"selected='selected'":""?>>Company</option>
		</select>
		<input type="text" id="searchval" style="width: 150px;"  value="<?php echo $filter['searchval']?>">
		<select id="searchprog" style="width: 100px">
			<option value="" <?php echo $filter['searchprog']==""?"selected='selected'":""?>>Programs</option>
			<?php foreach ($programs as $program):?>
			<option value="<?php echo $program['pid']?>" <?php echo $filter['searchprog']==$program['pid']?"selected='selected'":""?>><?php echo $program['program']?></option>
			<?php endforeach;?>
		</select>
		<select id="searchstatus" style="width: 80px;">
			<option value="all" <?php echo $filter['searchstatus']=="all"?"selected='selected'":""?>>Status</option>
			<option value="Won" <?php echo $filter['searchstatus']=="Won"?"selected='selected'":""?>>Won</option>
			<option value="Pending" <?php echo $filter['searchstatus']=="Pending"?"selected='selected'":""?>>Pending</option>
			<option value="Loss" <?php echo $filter['searchstatus']=="Loss"?"selected='selected'":""?>>Loss</option>
			<option value="Rejected" <?php echo $filter['searchstatus']=="Rejected"?"selected='selected'":""?>>Rejected</option>
		</select>		
		<button type="submit" id="gosearch"><img src="assets/images/icons/find.png">Go</button>
	</div>
</form>
<div class="noborderlist" id="tbinfos" style="padding-top:2px;">
	<table cellspacing="0" cellpadding="0" border="0">
	<thead>
		<tr>
		<th width="15px">#</th><th>Name</th><th>Status</th><th colspan="2">Company</th>
		</tr>
	</thead>
	<tbody>
	<?php if(count($results->result_array())>0):?>
	<?php $i=1+$counter;?>
	<?php foreach ($results->result_array() as $value):?>
		<tr id="<?php echo $value['infoid']?>">
			<td style="font-size:11px;" width="20px"><?php echo $i;?> )</td>
			<td class="info"><?php echo $value['name']?></td>
			<td><?php echo $value['status']?></td>
			<td><?php echo $value['companyName']?></td>
			<td align="right">
				<a id="<?php echo $value['did']?>" class="history">Details</a>&nbsp;&nbsp;<?php if(my_session_value('showalldays')==""):?><a id="<?php echo $value['infoid']?>" class="copyinfo">Copy</a><?php endif;?>
			</td>
		</tr>
		<?php $i++; ?>
	<?php endforeach;?>
	<tr>
	<td colspan="5" style="border-bottom: 0"><div style="float: left;" id="infopages"><?php echo $this->ajaxpagination->create_links()?></div>
		<span style="float: right;font-weight: bold;font-size: 11px;"><?php echo $msg?></span></td>
	</tr>
	<?php else:?>
	<tr>
	<td colspan="5" style="border-bottom: 0"><div id="infopages">no record found</div></td>
	</tr>
	<?php endif;?>		
	</tbody>
	</table>
</div>
<input type="hidden" value="<?php echo $userid?>" id="userid">
<input type="hidden" value="<?php echo $programtempid?>" id="programtempid">