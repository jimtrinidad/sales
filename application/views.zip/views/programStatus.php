<script type="text/javascript">
$(document).ready(function(){
	$('#programstatus_panel #close').bind('click',function(e){
		$('#programstatus_panel').fadeOut(500);
		addprogram=false;
	});
});
</script>
<div id="programstatus_container">
	<div class="header">
	<span style="float:left;margin:5px;font-weight:bold"><?php echo $title?> Status</span> 
	<span id="close" style="float: right;margin: 5px;font-weight: bold">x</span>
	<div class="clearer"></div>
	</div>
	<div class="programstatus_content noborderlist">
		<table cellpadding="0" cellspacing="0">
			<thead>
				<tr>
					<th></th><th>Weekly Target</th><th>Weekly Won</th><th>Weely Percent</th>
					<th>Accum. Target</th><th>Accum. Won</th><th>Accumulated Percent</th>
				</tr>
			</thead>
			<tbody id="tb" >
				<?php $i=1; foreach ($weeks as $v):?>
				<tr 
					<?php if(date("W",strtotime(NOW))>$v['weekNo'] && $i<$middle && $v['weeklyPercent']<=50):?>style="background: #d7d511"<?php endif;?>
					<?php if(date("W",strtotime(NOW))>$v['weekNo'] && $i>=$middle && $v['accumPercent']<=50):?>style="background: #df7300"<?php endif;?>
				>
					<td class="w" <?php echo date("W",strtotime(NOW))==$v['weekNo']?"style='font-size:15px;background: #11abd7;'":"";?>><?php echo "Week {$i}"?></td>
					<td class="n"><?php echo $v['tPerWeek']?></td>
					<td class="n"><?php echo $v['wonPerWeek']?></td>
					<td class="d n"><?php echo $v['weeklyPercent']?>%</td>	
					<td class="n"><?php echo $v['accumTargetPerWeek']?></td>
					<td class="n"><?php echo $v['accumWonPerWeek']?></td>				
					<td class="d n"><?php echo $v['accumPercent']?>%</td>
				</tr>
				<?php $i++; endforeach;?>
				<tr class="t">
					<td colspan="2" style="text-align: left;">
						<span>Final Result</span> 
					</td>
					<td colspan="5" style="text-align: right;">
						<span>Target:</span><b style="margin-right:10px;"><?php echo $totals['target']?></b> 				
						<span>Won:</span><b><?php echo $totals['totalwon']?></b>
						<b>(<?php echo round($totals['totalwon']/($totals['target']!=0?$totals['target']:1)*100,2)?>%)</b>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>