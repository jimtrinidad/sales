		<table cellpadding="0" cellspacing="0" id="sortTable">
			<thead>
				<tr>
					<th>Program</th><th>Date Range</th><th>Previous Weeks Totals</th>
					<?php foreach ($th as $head):?>
					<th><?php echo date("l",$head)."<br>".date("n/j/y",$head)?></th>
					<?php endforeach;?>
					<th>Totals</th>
				</tr>
			</thead>
			<tbody >
				<?php foreach ($final as $value):?>
				<tr id="tb" >
					<td>
						<img src="<?php echo base_url()?>assets/photos/logo/<?php echo $value['logo']?>" width="55px" height="40px"><br>
						<b><?php echo $value['program']." ".$value['batch']?></b></td>
					<td class="d"><?php echo date("j M, y",strtotime($value['dateStart']))." - ".date("j M, y",strtotime($value['dateEnd']))?></td>
					<td class="l n"><?php if(userPrivilege('dashDetail')==1 && $value['lastweeks']>0):?><a class="dashtrigger n"<?php echo "lw='1' date='{$value['lastweeksfilter']['lastweeks']}' program='{$value['lastweeksfilter']['program']}' status='{$value['lastweeksfilter']['status']}'"; ?>><?php echo $value['lastweeks']?></a><?php else: echo $value['lastweeks']; endif;?></td>
					<td class="n"><?php if(userPrivilege('dashDetail')==1 && $value['mon']>0):?><a class="dashtrigger n" <?php echo "date='{$value['monfilter']['day']}' program='{$value['monfilter']['program']}' status='{$value['monfilter']['status']}'"; ?>><?php echo $value['mon']?></a><?php else: echo $value['mon']; endif;?></td>
					<td class="n"><?php if(userPrivilege('dashDetail')==1 && $value['tue']>0):?><a class="dashtrigger n" <?php echo "date='{$value['tuefilter']['day']}' program='{$value['tuefilter']['program']}' status='{$value['tuefilter']['status']}'"; ?>><?php echo $value['tue']?></a><?php else: echo $value['tue']; endif;?></td>
					<td class="n"><?php if(userPrivilege('dashDetail')==1 && $value['wed']>0):?><a class="dashtrigger n" <?php echo "date='{$value['wedfilter']['day']}' program='{$value['wedfilter']['program']}' status='{$value['wedfilter']['status']}'"; ?>><?php echo $value['wed']?></a><?php else: echo $value['wed']; endif;?></td>
					<td class="n"><?php if(userPrivilege('dashDetail')==1 && $value['thu']>0):?><a class="dashtrigger n" <?php echo "date='{$value['thufilter']['day']}' program='{$value['thufilter']['program']}' status='{$value['thufilter']['status']}'"; ?>><?php echo $value['thu']?></a><?php else: echo $value['thu']; endif;?></td>
					<td class="n"><?php if(userPrivilege('dashDetail')==1 && $value['fri']>0):?><a class="dashtrigger n" <?php echo "date='{$value['frifilter']['day']}' program='{$value['frifilter']['program']}' status='{$value['frifilter']['status']}'"; ?>><?php echo $value['fri']?></a><?php else: echo $value['fri']; endif;?></td>
					<td class="n t"><?php if(userPrivilege('dashDetail')==1 && $value['total']>0):?><a class="dashtrigger n" <?php echo "lw='2' date='{$value['weektotalfilter']['weekfrom']}' program='{$value['weektotalfilter']['program']}' status='{$value['weektotalfilter']['status']}'"; ?>><?php echo $value['total']?></a><?php else: echo $value['total']; endif;?></td>
				</tr>
				<?php endforeach;?>
			</tbody>
			<tfoot>
				<tr class="dashTotal">
					<td colspan="2"><b>Totals</b></td>
					<td class="l n"><?php echo $dailyTotals['prevWeekTot']?></td>
					<td class="n"><?php echo $dailyTotals['monTot']?></td>
					<td class="n"><?php echo $dailyTotals['tueTot']?></td>
					<td class="n"><?php echo $dailyTotals['wedTot']?></td>
					<td class="n"><?php echo $dailyTotals['thuTot']?></td>
					<td class="n"><?php echo $dailyTotals['friTot']?></td>
					<td class="n t"><?php echo $dailyTotals['allWeekTot']?></td>
				</tr>			
			</tfoot>
		</table>
		
<script type="text/javascript">
$(document).ready(function(){

	$(".dashtrigger").bind("click",function(){
		var fdata = {
					lw : $(this).attr('lw'),
					day : $(this).attr('date'),
					program : $(this).attr('program'),
					status : $(this).attr('status'),
					ajax : 1
				};
			//alert(fdata['day'] + " | "+ fdata['program'] + " | "+ fdata['status']);
		$("#dashboarddetailscontainer").empty().html("<img  style='margin:50px 0 30px 590px;' src='<?php echo base_url() ?>assets/images/bigloader.gif'>");
		$.ajax({
			url : '<?php echo site_url('dashboard/getDetails')?>',
			type : 'POST',
			data : fdata,
			success : function(msg){
				$("#dashboarddetails_panel").html(msg);
				$("#dashboarddetailsholder").fadeIn('fast');
			},
			error : function(){
				//alert('g');
			}
		});
	});
	
	$("#sortTable").tablesorter({
		cssHeader : 'thHeader'
	}); 
	
});
</script>		