	<table cellspacing="0" cellpadding="0" border="0">
	<thead>
		<tr>
		<th width="15px">#</th><th>Name</th><th>Status</th><th colspan="2">Company</th>
		</tr>
	</thead>
	<tbody>
	<?php if(count($results->result_array())>0):?>
	<?php $i=1+$counter;?>
	<?php foreach ($results->result_array() as $value):?>
		<tr id="<?php echo $value['infoid']?>">
			<td style="font-size:11px;" width="20px"><?php echo $i;?> )</td>
			<td class="info"><?php echo $value['name']?></td>
			<td><?php echo $value['status']?></td>
			<td><?php echo $value['companyName']?></td>
			<td align="right">
				<a id="<?php echo $value['did']?>" class="history">Details</a>&nbsp;&nbsp;<?php if(my_session_value('showalldays')==""):?><a id="<?php echo $value['infoid']?>" class="copyinfo">Copy</a><?php endif;?>
			</td>
		</tr>
		<?php $i++; ?>
	<?php endforeach;?>
	<tr>
	<td colspan="5" style="border-bottom: 0"><div style="float: left;" id="infopages"><?php echo $this->ajaxpagination->create_links()?></div>
		<span style="float: right;font-weight: bold;font-size: 11px;"><?php echo $msg?></span></td>
	</tr>
	<?php else:?>
	<tr>
	<td colspan="5" style="border-bottom: 0"><div id="infopages">no record found</div></td>
	</tr>
	<?php endif;?>		
	</tbody>
	</table>
	
<script type="text/javascript">
function getRecord(id){
	var fdata = {
			id:id,
			ajax:'1'
			};
	$("#copyevent_panel").empty().html("<div class='infoloader'><img style='margin-left:20px;' src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
	$.ajax({
		url : '<?php echo site_url('main/getOldRecForEditor')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#copyevent_panel").html(msg);
		},
		error : function(){
			//alert('g');
		}
	});
}
function getHistory(id){
	var fdata = {
			id:id,
			showall : 1,
			ajax:'1'
			};
	$.ajax({
		url : '<?php echo site_url('main/getHistory')?>',
		data : fdata,
		type : 'POST',
		success : function(msg){
			$("#history_panel").html(msg);
		},
		error : function(){
			//alert(id);
		}
	});	
}
$(document).ready(function(){
	$("#infopages #pagination span").click(function(){
		$("#tbinfos").empty().html("<div class='infoloader' style='width:560px;'><img style='left:245px;' src='<?php echo base_url() ?>assets/images/bigloader.gif'></div>");
		$.ajax({
			url : $(this).attr("href"),
			data : ajax = '1',
			type : 'GET',
			success : function(res){
				$("#tbinfos").html(res);
			}
		});
	});	

	var copyinfo = false;
	var row = null;
	$(".copyinfo").bind("click",function(){
		if(row){
			if(copyinfo && $(this).attr('id')==row){
				$("#copyevent_panel").fadeOut('fast');
				copyinfo = false;
			}else if(copyinfo){
				$("#copyevent_panel").fadeOut('fast');
				getRecord($(this).attr('id'));
				$("#copyevent_panel").fadeIn('fast');
				copyinfo = true;
			}else{
				$("#copyevent_panel").fadeIn('fast');
				getRecord($(this).attr('id'));
				copyinfo = true;				
			}
		}
		else
		{
			if(!copyinfo){
				$("#copyevent_panel").fadeIn('fast');
				getRecord($(this).attr('id'));
				copyinfo = true;
			}
		}
		row = $(this).attr('id');		
	});	
	
	var history = false;
	var hisRow = null;
	$(".history").bind("click",function(){
		if(hisRow){
			if(history && $(this).attr('id')==hisRow){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				history = false;
			}else if(history){
				$("#history_panel").animate({"left": "-430px"}, "fast");
				getHistory($(this).attr('id'));
				$("#history_panel").animate({"left": "0px"}, "fast");
				history = true;
			}else{
				$("#history_panel").animate({"left": "0px"}, "fast");
				getHistory($(this).attr('id'));
				history = true;				
			}
		}
		else
		{
			if(!history){
				$("#history_panel").animate({"left": "0px"}, "fast");
				getHistory($(this).attr('id'));
				history = true;
			}
		}
		hisRow = $(this).attr('id');		
	});						
			
});
</script>		